#include<iostream>

int main()
{
     int x = 4;
    int* ptr = &x; 
    std::cout << &x << "\n";
    return 0;
}